from django.contrib import admin
from Diabetes.models import Diabetes_data , FeedBack

# Register your models here.
admin.site.register(Diabetes_data)
admin.site.register(FeedBack)